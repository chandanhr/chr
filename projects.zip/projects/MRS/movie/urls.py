from django.urls import path
from . import views

urlpatterns = [
    path('train_model', views.train , name= 'train'),
    path('',views.home , name= 'home'),
    path('result', views.result, name='result'),
    path('test_model', views.test , name= 'test')
]