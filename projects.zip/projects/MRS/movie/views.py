from django.shortcuts import render
from django.http import HttpResponse
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
# Create your views here.


def home(request):
    return render(request,'index.html')

def train(request):
    dataset = pd.read_csv('https://raw.githubusercontent.com/chandanhr/chr/master/Movie_Id_Titles')
    data= dataset.to_html
    udataset = pd.read_csv('https://raw.githubusercontent.com/chandanhr/chr/master/udata.csv')
    udata = udataset.to_html
    return render(request,'model.html',{'data':data,'udata':udata})
    
def result(request):
    moviename= request.POST['t1'] 
    column_names = ['user_id', 'item_id', 'rating', 'timestamp']
    df = pd.read_csv('https://raw.githubusercontent.com/chandanhr/chr/master/u.data', sep='\t', names=column_names)
    df.head()
    movie_titles = pd.read_csv("https://raw.githubusercontent.com/chandanhr/chr/master/Movie_Id_Titles")
    movie_titles.head()
    df = pd.merge(df,movie_titles,on='item_id')
    df.head()
    df.groupby('title')['rating'].mean().sort_values(ascending=False).head()
    df.groupby('title')['rating'].count().sort_values(ascending=False).head()
    ratings = pd.DataFrame(df.groupby('title')['rating'].mean())
    ratings['num of ratings'] = pd.DataFrame(df.groupby('title')['rating'].count())
    moviemat = df.pivot_table(index='user_id',columns='title',values='rating')
    ratings.sort_values('num of ratings',ascending=False).head(10)

    def check(title):
        if(moviename==title):
            return 1
        
    x=movie_titles['title'].apply(check)
    flag=False
    for i in range(0,1682):
        if(x[i]==1):
            flag= True
            break
    if(flag==False):
        return render(request,'result.html',{'result':'Movie name not found'})
    starwars_user_ratings = moviemat[moviename]
    starwars_user_ratings.head()
    similar_to_starwars = moviemat.corrwith(starwars_user_ratings)
    corr_starwars = pd.DataFrame(similar_to_starwars,columns=['Correlation'])
    corr_starwars.dropna(inplace=True)
    corr_starwars.head()
    corr_starwars.sort_values('Correlation',ascending=False).head(10)
    corr_starwars = corr_starwars.join(ratings['num of ratings'])
    corr_starwars.head()
    result = corr_starwars[corr_starwars['num of ratings']>100].sort_values('Correlation',ascending=False)
    result.head()
    return render(request,'result.html',{'result':result.head().to_html})

def test(request):
    return render(request,'test.html')